Samples included with the Microsoft Excel 2013 XLL Software Development Kit (SDK):

Example  	Code from the API Reference chapter examples.
		Note: In order for Excel to find and load Example.xll when you
		open Example.xlsm, you should place your built copy of Example.xll
		in Excel's current working directory (CWD), which is typically
		Excel's default save directory (and not the location of the Excel
		workbook).

FrameWrk 	Files for generating the XLL framework lib file for use
		in add-ins.

Generic         A sample XLL that shows how to use framework features and
		a few Excel functions.
